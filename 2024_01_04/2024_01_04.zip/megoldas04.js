let a=Number(prompt("Adj meg egy számot"));
let b=Number(prompt("Adj meg még egy osztót"));
if(a%b==0){
	document.write(`A ${a}, ${b},  maradéka nulla.
`);
}
else{
	document.write(`A ${a}, ${b}, a maradék nem nulla`);
}