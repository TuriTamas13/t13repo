for(let i=0;i<=10;i++){
	let hatvany=Math.pow(2,i);
    document.write(hatvany+",");
}