let kor=Number(prompt("Add meg az életkort"));
if(kor>0 && kor<=6){
	document.write(`A illető besorolása: Kisgyermekkor`);
}

else if(kor>6 && kor<=12){
	document.write(`A illető besorolása: Gyermekkor`);
}

else if(kor>12 && kor<=16){
	document.write(`A illető besorolása: Serdülőkor`);
}

else if(kor>16 && kor<=20){
	document.write(`A illető besorolása: Ifjúkor`);
}

else if(kor>20 && kor<=30){
	document.write(`A illető besorolása: Fiatal felnőtt kor`);
}

else if(kor>30 && kor<=60){
	document.write(`A illető besorolása: Felnőttkor`);
}

else if(kor>60 && kor<=120){
	document.write(`A illető besorolása: Aggkor`);
}

else{
	document.write(`Hiba`);
}