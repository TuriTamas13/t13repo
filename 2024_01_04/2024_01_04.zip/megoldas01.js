document.write("Túri Tamás");
document.write("#Team13");
document.write("HTML:90");
document.write("CSS:85");
document.write("JavaScript:60");