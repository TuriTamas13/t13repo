let a=0;
while(a<=30){
	document.write(a+",");
    a+=2;
}